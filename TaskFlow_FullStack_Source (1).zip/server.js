require("dotenv").config();
const express = require("express");
const path = require("path");
const fs = require("fs");
const mongoose = require("mongoose");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "tasks.json");

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const TaskSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 120 },
  description: { type: String, default: "", maxlength: 1000 },
  status: { type: String, enum: ["todo", "inprogress", "done"], default: "todo" },
  priority: { type: String, enum: ["low", "medium", "high"], default: "medium" },
  dueDate: { type: String, default: "" },
  createdAt: { type: Date, default: Date.now }
});
const Task = mongoose.models.Task || mongoose.model("Task", TaskSchema);

let mongoConnected = false;

function ensureDataFile() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, "[]", "utf8");
}
function readLocalTasks() {
  ensureDataFile();
  return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
}
function writeLocalTasks(tasks) {
  ensureDataFile();
  fs.writeFileSync(DATA_FILE, JSON.stringify(tasks, null, 2), "utf8");
}
function newId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
function validateTask(body, partial = false) {
  const errors = [];
  if (!partial || body.title !== undefined) {
    if (typeof body.title !== "string" || !body.title.trim()) errors.push("Title is required.");
    else if (body.title.trim().length > 120) errors.push("Title must be 120 characters or fewer.");
  }
  if (body.description !== undefined && (typeof body.description !== "string" || body.description.length > 1000))
    errors.push("Description must be 1,000 characters or fewer.");
  if (body.status !== undefined && !["todo", "inprogress", "done"].includes(body.status))
    errors.push("Choose a valid status.");
  if (body.priority !== undefined && !["low", "medium", "high"].includes(body.priority))
    errors.push("Choose a valid priority.");
  if (body.dueDate !== undefined && body.dueDate !== "" && !/^\d{4}-\d{2}-\d{2}$/.test(body.dueDate))
    errors.push("Due date must use YYYY-MM-DD format.");
  return errors;
}

app.get("/api/health", (_req, res) => res.json({
  status: "ok",
  service: "TaskFlow API",
  database: mongoConnected ? "mongodb" : "local-json"
}));

app.get("/api/tasks", async (req, res, next) => {
  try {
    const { status, priority, search } = req.query;
    let tasks = mongoConnected
      ? (await Task.find().sort({ createdAt: -1 }).lean()).map(t => ({ ...t, id: String(t._id) }))
      : readLocalTasks().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    if (status && status !== "all") tasks = tasks.filter(t => t.status === status);
    if (priority && priority !== "all") tasks = tasks.filter(t => t.priority === priority);
    if (search) {
      const q = String(search).toLowerCase();
      tasks = tasks.filter(t => t.title.toLowerCase().includes(q) || (t.description || "").toLowerCase().includes(q));
    }
    res.json({ data: tasks, count: tasks.length });
  } catch (err) { next(err); }
});

app.post("/api/tasks", async (req, res, next) => {
  try {
    const errors = validateTask(req.body);
    if (errors.length) return res.status(400).json({ errors });
    const taskData = {
      title: req.body.title.trim(),
      description: (req.body.description || "").trim(),
      status: req.body.status || "todo",
      priority: req.body.priority || "medium",
      dueDate: req.body.dueDate || "",
      createdAt: new Date().toISOString()
    };
    let task;
    if (mongoConnected) {
      const doc = await Task.create(taskData);
      task = { ...doc.toObject(), id: String(doc._id) };
    } else {
      const tasks = readLocalTasks();
      task = { ...taskData, id: newId() };
      tasks.push(task);
      writeLocalTasks(tasks);
    }
    res.status(201).json({ data: task, message: "Task created successfully." });
  } catch (err) { next(err); }
});

app.patch("/api/tasks/:id", async (req, res, next) => {
  try {
    const errors = validateTask(req.body, true);
    if (errors.length) return res.status(400).json({ errors });
    const allowed = ["title", "description", "status", "priority", "dueDate"];
    const updates = {};
    for (const key of allowed) if (req.body[key] !== undefined) updates[key] = typeof req.body[key] === "string" && key === "title" ? req.body[key].trim() : req.body[key];
    let task;
    if (mongoConnected) {
      if (updates.title !== undefined && !updates.title) return res.status(400).json({ errors: ["Title is required."] });
      task = await Task.findByIdAndUpdate(req.params.id, updates, { new: true, runValidators: true }).lean();
      if (task) task = { ...task, id: String(task._id) };
    } else {
      const tasks = readLocalTasks();
      const index = tasks.findIndex(t => t.id === req.params.id);
      if (index !== -1) {
        tasks[index] = { ...tasks[index], ...updates };
        writeLocalTasks(tasks);
        task = tasks[index];
      }
    }
    if (!task) return res.status(404).json({ errors: ["Task not found."] });
    res.json({ data: task, message: "Task updated successfully." });
  } catch (err) { next(err); }
});

app.delete("/api/tasks/:id", async (req, res, next) => {
  try {
    let deleted = false;
    if (mongoConnected) deleted = Boolean(await Task.findByIdAndDelete(req.params.id));
    else {
      const tasks = readLocalTasks();
      const nextTasks = tasks.filter(t => t.id !== req.params.id);
      deleted = nextTasks.length !== tasks.length;
      if (deleted) writeLocalTasks(nextTasks);
    }
    if (!deleted) return res.status(404).json({ errors: ["Task not found."] });
    res.json({ message: "Task deleted successfully." });
  } catch (err) { next(err); }
});

app.get("/api/stats", async (_req, res, next) => {
  try {
    const tasks = mongoConnected
      ? await Task.find().lean()
      : readLocalTasks();
    res.json({ data: {
      total: tasks.length,
      todo: tasks.filter(t => t.status === "todo").length,
      inprogress: tasks.filter(t => t.status === "inprogress").length,
      done: tasks.filter(t => t.status === "done").length,
      highPriority: tasks.filter(t => t.priority === "high" && t.status !== "done").length
    }});
  } catch (err) { next(err); }
});

app.use("/api", (_req, res) => res.status(404).json({ errors: ["API endpoint not found."] }));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ errors: ["Unexpected server error. Please try again."] });
});

async function start() {
  if (process.env.MONGODB_URI) {
    try {
      await mongoose.connect(process.env.MONGODB_URI);
      mongoConnected = true;
      console.log("Connected to MongoDB.");
    } catch (err) {
      console.error("MongoDB connection failed:", err.message);
      console.error("Stopping startup because MONGODB_URI was supplied but unavailable.");
      process.exit(1);
    }
  } else {
    console.log("Using local JSON file storage. Configure MONGODB_URI for persistent cloud deployment.");
  }
  app.listen(PORT, () => console.log(`TaskFlow running on http://localhost:${PORT}`));
}
start();
