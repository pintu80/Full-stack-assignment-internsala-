const $ = (id) => document.getElementById(id);
const state = { tasks: [], stats: { total: 0, todo: 0, inprogress: 0, done: 0, highPriority: 0 } };
const statusNames = { todo: "To do", inprogress: "In progress", done: "Completed" };
const priorityNames = { low: "Low", medium: "Medium", high: "High" };

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
}
function prettyDate(dateString) {
  if (!dateString) return "";
  const d = new Date(`${dateString}T00:00:00`);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}
function isOverdue(dateString, status) {
  if (!dateString || status === "done") return false;
  const today = new Date(); today.setHours(0,0,0,0);
  return new Date(`${dateString}T00:00:00`) < today;
}
function showToast(message) {
  const toast = $("toast"); toast.textContent = message; toast.classList.add("show");
  clearTimeout(showToast.timer); showToast.timer = setTimeout(() => toast.classList.remove("show"), 2600);
}
async function api(url, options = {}) {
  const response = await fetch(url, { ...options, headers: { "Content-Type": "application/json", ...(options.headers || {}) } });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error((result.errors || ["Something went wrong."])[0]);
  return result;
}
async function loadTasks() {
  try {
    const params = new URLSearchParams();
    if ($("statusFilter").value !== "all") params.set("status", $("statusFilter").value);
    if ($("priorityFilter").value !== "all") params.set("priority", $("priorityFilter").value);
    if ($("searchInput").value.trim()) params.set("search", $("searchInput").value.trim());
    const [taskResult, statsResult] = await Promise.all([api(`/api/tasks?${params}`), api("/api/stats")]);
    state.tasks = taskResult.data || []; state.stats = statsResult.data;
    renderStats(); renderTasks();
  } catch (err) {
    $("taskList").innerHTML = `<div class="empty-state"><strong>Could not load tasks</strong>${escapeHtml(err.message)}. Refresh the page to try again.</div>`;
    showToast(err.message);
  }
}
function renderStats() {
  const s = state.stats;
  $("totalStat").textContent = s.total; $("todoStat").textContent = s.todo;
  $("progressStat").textContent = s.inprogress; $("doneStat").textContent = s.done;
  $("completionRate").textContent = `${s.total ? Math.round(s.done / s.total * 100) : 0}%`;
  $("navTaskCount").textContent = s.total;
}
function renderTasks() {
  $("visibleCount").textContent = state.tasks.length;
  if (!state.tasks.length) {
    const hasFilters = $("searchInput").value || $("statusFilter").value !== "all" || $("priorityFilter").value !== "all";
    $("taskList").innerHTML = `<div class="empty-state"><div class="empty-icon">✦</div><strong>${hasFilters ? "No matching tasks" : "A fresh start."}</strong><span>${hasFilters ? "Try changing your search or filters." : "Create your first task and turn an idea into action."}</span></div>`;
    $("footerMessage").textContent = hasFilters ? "Nothing matches those filters." : "Your next great result starts here.";
    return;
  }
  $("footerMessage").textContent = `${state.stats.done} of ${state.stats.total} tasks completed. Keep going!`;
  $("taskList").innerHTML = state.tasks.map(task => {
    const date = prettyDate(task.dueDate);
    return `<article class="task-row ${task.status === "done" ? "is-done" : ""}">
      <div class="task-main"><input class="task-check" type="checkbox" aria-label="Mark ${escapeHtml(task.title)} complete" data-action="toggle" data-id="${escapeHtml(task.id)}" ${task.status === "done" ? "checked" : ""}><div class="task-copy"><div class="task-title">${escapeHtml(task.title)}</div>${task.description ? `<div class="task-description">${escapeHtml(task.description)}</div>` : ""}${date ? `<div class="due-date ${isOverdue(task.dueDate, task.status) ? "overdue" : ""}">${isOverdue(task.dueDate, task.status) ? "Overdue · " : "Due "}${date}</div>` : ""}</div></div>
      <div class="task-meta status-meta"><span class="status-pill status-${task.status}">${statusNames[task.status]}</span></div>
      <div class="task-meta priority-meta"><span class="priority-pill priority-${task.priority}">${priorityNames[task.priority]} priority</span></div>
      <div class="row-actions"><button class="icon-btn" title="Edit task" aria-label="Edit ${escapeHtml(task.title)}" data-action="edit" data-id="${escapeHtml(task.id)}">✎</button><button class="icon-btn" title="Delete task" aria-label="Delete ${escapeHtml(task.title)}" data-action="delete" data-id="${escapeHtml(task.id)}">×</button></div>
    </article>`;
  }).join("");
}
function openModal(task = null) {
  $("taskForm").reset();
  $("taskId").value = task?.id || "";
  $("modalTitle").textContent = task ? "Edit task" : "Create a task";
  $("saveTaskBtn").innerHTML = task ? "Save changes <span>→</span>" : "Save task <span>→</span>";
  $("taskTitle").value = task?.title || "";
  $("taskDescription").value = task?.description || "";
  $("taskStatus").value = task?.status || "todo";
  $("taskPriority").value = task?.priority || "medium";
  $("taskDueDate").value = task?.dueDate || "";
  $("taskModal").classList.add("open"); $("taskModal").setAttribute("aria-hidden", "false");
  setTimeout(() => $("taskTitle").focus(), 60);
}
function closeModal() { $("taskModal").classList.remove("open"); $("taskModal").setAttribute("aria-hidden", "true"); }
$("addTaskBtn").addEventListener("click", () => openModal());
$("closeModalBtn").addEventListener("click", closeModal);
$("cancelModalBtn").addEventListener("click", closeModal);
$("taskModal").addEventListener("click", e => { if (e.target === $("taskModal")) closeModal(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });
$("taskForm").addEventListener("submit", async e => {
  e.preventDefault();
  const id = $("taskId").value;
  const payload = { title: $("taskTitle").value.trim(), description: $("taskDescription").value.trim(), status: $("taskStatus").value, priority: $("taskPriority").value, dueDate: $("taskDueDate").value };
  if (!payload.title) return showToast("Please enter a task title.");
  $("saveTaskBtn").disabled = true;
  try {
    await api(id ? `/api/tasks/${encodeURIComponent(id)}` : "/api/tasks", { method: id ? "PATCH" : "POST", body: JSON.stringify(payload) });
    closeModal(); await loadTasks(); showToast(id ? "Task updated successfully." : "Task created successfully.");
  } catch (err) { showToast(err.message); }
  finally { $("saveTaskBtn").disabled = false; }
});
$("taskList").addEventListener("click", async e => {
  const control = e.target.closest("[data-action]"); if (!control) return;
  const { action, id } = control.dataset;
  const task = state.tasks.find(t => t.id === id);
  if (!task) return;
  if (action === "edit") return openModal(task);
  if (action === "delete") {
    if (!confirm(`Delete "${task.title}"? This cannot be undone.`)) return;
    try { await api(`/api/tasks/${encodeURIComponent(id)}`, { method: "DELETE" }); await loadTasks(); showToast("Task deleted."); }
    catch (err) { showToast(err.message); }
  }
});
$("taskList").addEventListener("change", async e => {
  const control = e.target.closest('[data-action="toggle"]'); if (!control) return;
  const task = state.tasks.find(t => t.id === control.dataset.id); if (!task) return;
  try {
    await api(`/api/tasks/${encodeURIComponent(task.id)}`, { method: "PATCH", body: JSON.stringify({ status: control.checked ? "done" : "todo" }) });
    await loadTasks(); showToast(control.checked ? "Task completed!" : "Task moved to To do.");
  } catch (err) { control.checked = !control.checked; showToast(err.message); }
});
let searchTimer;
$("searchInput").addEventListener("input", () => { clearTimeout(searchTimer); searchTimer = setTimeout(loadTasks, 220); });
$("statusFilter").addEventListener("change", loadTasks);
$("priorityFilter").addEventListener("change", loadTasks);
$("clearFiltersBtn").addEventListener("click", () => { $("searchInput").value = ""; $("statusFilter").value = "all"; $("priorityFilter").value = "all"; loadTasks(); });
$("todayLabel").textContent = new Date().toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
loadTasks();
