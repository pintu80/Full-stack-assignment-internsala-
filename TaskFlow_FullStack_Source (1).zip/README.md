# TaskFlow — Full-Stack Task Management Dashboard

TaskFlow is a responsive task management web application built with **Node.js, Express, vanilla JavaScript, and MongoDB**. It demonstrates CRUD operations, REST API design, data validation, search/filtering, dashboard statistics, and deployment configuration.

## Features
- Create, view, edit, complete, and delete tasks
- Task status: To do, In progress, Completed
- Priority: Low, Medium, High
- Optional due dates and overdue indicators
- Live search and status/priority filters
- Dashboard summary statistics and completion rate
- Responsive desktop/mobile interface
- Server-side validation and consistent API errors
- MongoDB Atlas support for persistent hosted data
- Local JSON fallback for a quick offline/local demo

## Tech stack
- Frontend: HTML5, CSS3, JavaScript (Fetch API)
- Backend: Node.js + Express
- Database: MongoDB with Mongoose (recommended for deployment); JSON file fallback locally
- Hosting: Render (web service) + MongoDB Atlas

## Run locally
1. Install Node.js 18 or newer.
2. Extract this project and open a terminal in the project folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Copy `.env.example` to `.env`. For local mode, leave `MONGODB_URI` empty.
5. Start:
   ```bash
   npm start
   ```
6. Open `http://localhost:3000`.

## MongoDB Atlas setup for a public deployment
1. Create a free MongoDB Atlas cluster and a database user.
2. In Network Access, allow connections from your deployment provider (for a straightforward demo, `0.0.0.0/0` can be used with a strong database password; prefer tighter allowlists where practical).
3. Copy the application's connection string and replace the username/password and database name.
4. Keep the URI secret. Never commit `.env` or publish credentials.

## Deploy on Render
1. Push the extracted project to a new GitHub repository.
2. In Render, choose **New + → Web Service** and connect the repository.
3. Use build command `npm install` and start command `npm start`.
4. Add environment variable `MONGODB_URI` with the Atlas connection string.
5. Deploy. Render will assign a public URL such as `https://your-service-name.onrender.com`.
6. Open `/api/health` on that URL; expect JSON with `"status":"ok"` and `"database":"mongodb"`.
7. Open the root URL and test create/edit/complete/delete. The actual URL is assigned by Render and must be copied from your service dashboard.

**Important:** Do not deploy with `MONGODB_URI` empty if you need durable cloud data. The local JSON fallback is for local demos; free hosting filesystems may be ephemeral.

## REST API
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Health check |
| GET | `/api/tasks` | List tasks; supports `status`, `priority`, `search` query parameters |
| POST | `/api/tasks` | Create task |
| PATCH | `/api/tasks/:id` | Update task fields |
| DELETE | `/api/tasks/:id` | Delete task |
| GET | `/api/stats` | Dashboard totals |

### Example task payload
```json
{
  "title": "Prepare demo",
  "description": "Test all assignment flows",
  "status": "inprogress",
  "priority": "high",
  "dueDate": "2026-10-20"
}
```

## Suggested submission checklist
- [ ] Replace “Project Preview” with your name if desired
- [ ] Deploy with MongoDB Atlas configured
- [ ] Test all CRUD actions on the public URL
- [ ] Verify `/api/health` reports MongoDB
- [ ] Add the live URL and repository URL to your assignment submission
- [ ] Be ready to explain the REST endpoints, validation, database mode, and UI state updates

## Project structure
```text
taskflow-fullstack/
├── public/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── data/                 # created automatically for local JSON mode
├── server.js
├── package.json
├── .env.example
├── .gitignore
├── render.yaml
└── README.md
```
